module.exports = {
    user: 'primaoriondigital.prodigy@gmail.com',
    clientId: '678648448118-armb0dervkfpjrb05b8cmcp2f14krmcl.apps.googleusercontent.com',
    clientSecret: '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',
    refreshToken: '1//04FauC_kWPemJCgYIARAAGAQSNwF-L9IrILTeIvPUJX2-wN-6TXn8zd-hJJe5PDJac3BbRMBEHi7OQ5Ci-tT-rNOqx6c9aRqFnI8'
}