module.exports = {
    user: 'primaoriondigital.prodigy@gmail.com',
    clientId: '625061772933-cqc03d18oq25n31f4ssb40ep2nq4t933.apps.googleusercontent.com',
    clientSecret: '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',
    refreshToken: '1//04gYxE4SudAGLCgYIARAAGAQSNwF-L9IryZ8JDzwdY8yz7NycbKiZpzRmWdkd4QJKLfoI12RtkDC0zQWtAUKlRUDpntDdIZ_A-ro'
}